'use strict';

// ======================================================================
var	Agenda_OK =
{
  DatabaseName :	 'Agenda-OK',
  DatabaseVersion :	 1,
  DatabaseInitialized :	 false,
  DBMS :	 	null,
  authuser :		'',
  users :	 	[],
  events :	 	[],
  calendar :		[],
  todos :		[],
  nextEventID :		1,
  nextCategoryID :	1,
  nextResourceID :	1,
  nextActivityID :	1,
  nextTodoID :		1,
};

console.log ('AGENDA_OK');
