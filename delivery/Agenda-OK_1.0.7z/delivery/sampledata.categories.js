const sampleCategories =
[
	{ ID:1, user: 'root',  name: 'PERSONAL', priority: '2', color: 'blue' },
	{ ID:2, user: 'root',  name: 'BUSINESS', priority: '1', color: '#C0C0C0' },
	{ ID:3, user: 'root',  name: 'HOBBY',    priority: '3', color: 'red' },
	{ ID:4, user: 'pippo', name: 'PERSONAL', priority: '2', color: 'green' },
	{ ID:5, user: 'pippo', name: 'BUSINESS', priority: '1', color: '#808080' },
	{ ID:6, user: 'pippo', name: 'HOBBY',    priority: '3', color: 'cyan' },
];
