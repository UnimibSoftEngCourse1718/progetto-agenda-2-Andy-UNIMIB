const sampleTodos =
[
	{ id:1, user: 'root',  title: 'fare la spesa', priority: '2', color: 'blue' },
	{ id:2, user: 'root',  title: 'riformattare il server pippo', priority: '1', color: '#C0C0C0' },
	{ id:3, user: 'root',  title: 'isntallare qualche cosa su un server a caso',    priority: '3', color: 'red' },
	{ id:4, user: 'root',  title: 'sviluppare il progetto per l\'esame', priority: '2', color: 'green' },
	{ id:5, user: 'pippo', title: 'farsi una bella grigliata', priority: '1', color: '#808080' },
	{ id:6, user: 'pippo', title: 'mandarein assistenza la stampante',    priority: '3', color: 'cyan' },
];
