
// -------------- SAMPLE DATA ------------------
var	calendarSampleData =
      [
		{
		  title: 'All Day Event',
		  start: '2018-06-24',
		},
		{
		  title: 'Long Event',
		  start: '2018-06-24',
		  end: '2018-06-26'
		},
		{
		  id: 999,
		  title: 'Repeating Event',
		  start: '2018-06-24T16:00:00'
		},
		{
		  id: 999,
		  title: 'Repeating Event',
		  start: '2018-06-25T16:00:00'
		},
      ];
