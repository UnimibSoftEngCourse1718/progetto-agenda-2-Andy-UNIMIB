const sampleEvents =
[
	{ user: 'root',  priority: 1, id: 1,   title: 'Long Event',      start: '2018-06-21', end: '2018-06-26' },
	{ user: 'root',  priority: 2, id: 2,   title: 'All Day Event',   start: '2018-06-26', },
	{ user: 'root',  priority: 0, id: 3,   title: 'Repeating Event #2', start: '2018-06-24T16:00:00' },
	{ user: 'root',  priority: 1, id: 4,   title: 'Repeating Event #3', start: '2018-06-25T16:00:00' },
	{ user: 'pippo', priority: 0, id: 5,   title: 'All Day Event',   start: '2018-06-20', },
	{ user: 'pippo', priority: 1, id: 6,   title: 'auto dal meccanico',      start: '2018-06-18', end: '2018-06-21' },
	{ user: 'pluto', priority: 2, id: 7,   title: 'esame in Università',      start: '2018-06-17', end: '2018-06-19' },
	{ user: 'pluto', priority: 0, id: 12,  title: 'Repeating Event #1', start: '2018-06-13T16:00:00' },
];
