const sampleUsers =
[
	{ username: 'root',  password: 'admin', email: 'webmaster@company.com' },
	{ username: 'admin', password: 'admin', email: 'administrator@company.com' },
	{ username: 'demo',  password: 'demo',  email: 'demo@unimib.it' },
	{ username: 'prof',  password: 'prof',  email: 'prof@unimib.it' },
	{ username: 'pippo', password: 'X',     email: 'bill@company.com' },
	{ username: 'pluto', password: 'Y',     email: 'donna@home.org' }
];
